from logic import start
import games.even


def main():
    start(games.even)


if __name__ == '__main__':
    main()
