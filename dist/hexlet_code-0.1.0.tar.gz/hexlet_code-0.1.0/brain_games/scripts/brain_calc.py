from logic import start
import games.calc


def main():
    start(games.calc)


if __name__ == '__main__':
    main()